from urllib.request import Request,urlopen
import urllib.parse as parse
import ssl

def pijiu(record):
    for i in range(0,3):
        headers = {
            'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36'
        }

        data = {
            'wd':record,
            'pn':str(i*10)
        }

        data = parse.urlencode(data)
        url = 'https://www.baidu.com/s?' + data
        print(url)

        context = ssl._create_unverified_context()
        req = Request(url,headers=headers,method='GET')
        response = urlopen(req,context=context)

        with open(record + str(i) + '.html','w') as f:
            f.write(response.read().decode('utf-8'))

if __name__ == '__main__':
    record = str(input('请输入您要查找的:'))
    pijiu(record)