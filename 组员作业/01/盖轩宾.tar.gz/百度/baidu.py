import urllib.request
import urllib.parse
import ssl

context = ssl._create_unverified_context()
url = 'https://www.baidu.com'
wd = input('输入关键字')
for i in range(0,3):
    pn = i*10
    dict ={
        'wd':wd,
        'pn':pn
    }
    p = urllib.parse.urlencode(query=dict,encoding='utf-8')#将中文转化为编码格式
    print(p)

    newurl  = 'https://www.baidu.com/s?'+p+'&oq=huay1&ie=utf-8&rsv_idx=1&rsv_pq=afb28f8500031acf&rsv_t=f752qu55OJ4mH%2FaBvjMl%2FSZgcB16ninfn2kCis6j236Kiw45oKiWZJnUn7U'

    print(newurl)
    headers1 = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'
    }

    req = urllib.request.Request(newurl,headers=headers1)
    a = urllib.request.urlopen(req,context=context)
    b = a.read().decode('utf-8')
    f = 'b'+str(i)+'.html'

    with open(f,'w') as c:
        c.write(b)

    a.close()



