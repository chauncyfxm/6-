import urllib.request
import urllib.parse
import ssl
# https://www.baidu.com/s?ie=utf-8&f=3&rsv_bp=0&rsv_idx=1&tn=baidu&wd=%E7%AE%80%E4%B9%A6&rsv_pq=dd7b01c30001385b&rsv_t=1ddbHPrUP5WQQQ%2BsLcZ%2FgnVV0D9GjLQLCypK%2FnLXah1oW1XDFeNNvW1YVFs&rqlang=cn&rsv_enter=1&rsv_sug3=8&rsv_sug1=7&rsv_sug7=101&rsv_sug2=1&prefixsug=jianshu&rsp=0&inputT=2691&rsv_sug4=3840&rsv_jmp=fail

content = input('请输入你要输入的内容')

dict = {
    'wd':content
}
dict2 = {
    'oq':content
}
p = urllib.parse.urlencode(query=dict,encoding='utf-8')

p2 = urllib.parse.urlencode(query=dict2,encoding='utf-8')

# context = ssl._create_unverified_context()

for pn in range(0,30,10):
    pn = str(pn)

    url = 'http://www.baidu.com/s?'+ p + '&pn='+pn+'&' + p2 + '&ie=utf-8&rsv_idx=1&rsv_pq=8412768c0001bf3a&rsv_t=6333sOFUCM75Psomg5kGOwpFEARRKdN%2BOELGX13bQT%2Bi%2BG7LLiWIcXAPyUM'

    h = urllib.request.urlopen(url)

    response = h.read().decode('utf-8')

    f = open(pn+'.html','w')
    f.write(response)
    f.close() 
