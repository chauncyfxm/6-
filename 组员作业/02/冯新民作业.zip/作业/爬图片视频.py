import urllib.request
import urllib.parse
import ssl
import urllib.error
import re
import os

# 创建文件夹
def mkdir(path):
    # 引入模块
    import os
 
    # 去除首位空格
    path=path.strip()
    # 去除尾部 \ 符号
    path=path.rstrip("\\")
 
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists=os.path.exists(path)
 
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path) 
 
        print(path+' 创建成功')
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(path+' 目录已存在')
        return False
 
# 定义要创建的目录
# mkpath="d:\\qttc\\web\\"
# 调用函数
# mkdir(mkpath)










status = True

def parameter():
    i = 1
    while True:
        # url
        dict = {
            'pageNum':i
        }
        dict1 = urllib.parse.urlencode(dict, encoding='utf-8')
        url = 'https://www.readnovel.com/rank/hotsales?'+ dict1
        
        
        # context
        context = ssl._create_unverified_context()

        # headers
        headers = {
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
            'Cookie':'_csrfToken=1c5SF0w1Coghk4xA6vxWI2BhiODTiYFAkRUS4Kuk; newstatisticUUID=1530780906_1325563421',
            'Referer':'https://www.readnovel.com/rank/hotsales?pageNum=1',
        }
        
        run(url=url, headers=headers, context=context)
        
        if not status:
            break
        i += 1

def run(url, headers, context=None, data=None):
    url1 = urllib.request.Request(url,headers=headers)
    response = urllib.request.urlopen(url1,context=context, data=data)
    print(response.status)

    html = response.read().decode()
    

    pattren = re.compile('<li.*?<span.*?([0-9]+)</span>.*?<img src="(.*?)">.*?<h4><a href.*?>(.*?)</a></h4>.*?<a .*?>(.*?)</a>.*?<a href=.*?>(.*?)</a>.*?<p .*?>(.*?)</p>.*?<span>(.*?)</span>',re.S)
    reslut = re.findall(pattren,html)
    print(reslut)


    if not bool(reslut):
        status = False
    

    for i in reslut:
        imgurl = 'http:'+i[1]

        headers = {
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
        }
        imgurl1 = urllib.request.Request(imgurl,headers=headers)
        imgresponse = urllib.request.urlopen(imgurl1,context=context, data=data)
        imge = imgresponse.read()


        # 定义要创建的目录
        mkpath="D:\\6、爬虫初级\\2、post请求\\作业\\爬到的数据\\"+i[2]
        # 调用函数
        mkdir(mkpath)
        path = mkpath + "\\" + i[2] + '.jpg'
        with open(path, 'wb') as f:
            f.write(imge)
        
        for a in i:
            path = mkpath + "\\" + '信息' + '.txt'
            with open(path, 'a+') as f:
                f.write(a+'\n')


    


def main():
    parameter()

if __name__ == '__main__':
    main()
