import urllib.request
import ssl
import re
import os


# 创建文件夹
def mkdir(path):
    # 引入模块
    import os
 
    # 去除首位空格
    path=path.strip()
    # 去除尾部 \ 符号
    path=path.rstrip("\\")
 
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists=os.path.exists(path)
 
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path) 
 
        print(path+' 创建成功')
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(path+' 目录已存在')
        return False
 
# 定义要创建的目录
# mkpath="d:\\qttc\\web\\"
# 调用函数
# mkdir(mkpath)




context = ssl._create_unverified_context()#忽略ssl的数字证书
url = 'https://www.readnovel.com/rank/hotsales?pageNum=1'
headers = {
    'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
    'Referer':'https://www.readnovel.com/rank/hotsales?pageNum=10',
    'Cookie':'_csrfToken=cbXY0dTWcZYrQSCD10RP6jyL5QVcoe3jyunKPL5l; newstatisticUUID=1530780330_1380737860',
}#以浏览器身份访问

a = urllib.request.Request(url,headers=headers)#构造请求
b = urllib.request.urlopen(a,context=context)#发起请求
c = b.read().decode('utf-8')#将utf-8转为unicode编码

#<a href="/book/9500446903583303" target="_blank" data-eid="qd_C40" data-bid="9500446903583303">暖婚似火：顾少，轻轻宠</a>
#以正则来获取想要的东西    正则对象
d = re.compile('<li.*?<span.*?>(.*?)</span>.*?<img src="(.*?)">.*?<a.*?>(.*?)</a>.*?<a.*?>(.*?)</a>.*?<a.*?>(.*?)</a>.*?<p.*?>(.*?)</p>.*?<span>(.*?)</span>',re.S)
e = re.findall(d,c)
print(e)

for i in e:
    image_url = 'http:'+i[1]

    headers = {
         'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'
    }
    imagea = urllib.request.Request(image_url,headers=headers)#构造请求
    imageb = urllib.request.urlopen(imagea,context=context)#发起请求
    imagec = imageb.read()
    print(imageb.status)
    # 定义要创建的目录
    mkpath="/home/gxb/Desktop/第一周/小说阅读网-盖轩宾/爬取数据/"+i[2]+'/'
    # 调用函数
    mkdir(mkpath)
    with open(mkpath+i[2]+'.jpg','wb') as f:
        f.write(imagec)

    for i1 in i:
        with open(mkpath+'小说信息.txt','a+')as f1:
            f1.write(i1+'\n')
     
         




